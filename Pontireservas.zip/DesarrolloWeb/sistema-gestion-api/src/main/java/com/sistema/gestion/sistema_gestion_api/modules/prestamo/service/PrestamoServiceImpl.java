package com.sistema.gestion.sistema_gestion_api.modules.prestamo.service;

import com.sistema.gestion.sistema_gestion_api.modules.auth.service.UsuarioActual;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.dto.DevolucionRequestDTO;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.dto.PrestamoRequestDTO;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.dto.PrestamoResponseDTO;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.model.EstadoPrestamo;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.model.Prestamo;
import com.sistema.gestion.sistema_gestion_api.modules.prestamo.repository.PrestamoRepository;
import com.sistema.gestion.sistema_gestion_api.modules.recurso.model.EstadoOperativo;
import com.sistema.gestion.sistema_gestion_api.modules.recurso.model.ModalidadRecurso;
import com.sistema.gestion.sistema_gestion_api.modules.recurso.model.Recurso;
import com.sistema.gestion.sistema_gestion_api.modules.recurso.repository.RecursoRepository;
import com.sistema.gestion.sistema_gestion_api.modules.reserva.model.Reserva;
import com.sistema.gestion.sistema_gestion_api.modules.reserva.repository.ReservaRepository;
import com.sistema.gestion.sistema_gestion_api.modules.usuario.model.Usuario;
import com.sistema.gestion.sistema_gestion_api.modules.usuario.repository.UsuarioRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.List;

@Service
public class PrestamoServiceImpl implements PrestamoService {

    private final PrestamoRepository prestamoRepository;
    private final RecursoRepository recursoRepository;
    private final UsuarioRepository usuarioRepository;
    private final ReservaRepository reservaRepository;
    private final UsuarioActual usuarioActual;

    public PrestamoServiceImpl(PrestamoRepository prestamoRepository,
                               RecursoRepository recursoRepository,
                               UsuarioRepository usuarioRepository,
                               ReservaRepository reservaRepository,
                               UsuarioActual usuarioActual) {
        this.prestamoRepository = prestamoRepository;
        this.recursoRepository = recursoRepository;
        this.usuarioRepository = usuarioRepository;
        this.reservaRepository = reservaRepository;
        this.usuarioActual = usuarioActual;
    }

    @Override
    public List<PrestamoResponseDTO> listarTodos() {
        if (usuarioActual.esSolicitante()) {
            return prestamoRepository.findByUsuarioId(usuarioActual.id()).stream()
                    .map(this::toResponse)
                    .toList();
        }
        return prestamoRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public PrestamoResponseDTO obtenerPorId(Long id) {
        Prestamo prestamo = buscarEntidad(id);
        validarPropiedad(prestamo);
        return toResponse(prestamo);
    }

    @Override
    public List<PrestamoResponseDTO> buscarPorRecurso(Long recursoId) {
        List<Prestamo> prestamos = prestamoRepository.findByRecursoId(recursoId);
        if (usuarioActual.esSolicitante()) {
            Long actualId = usuarioActual.id();
            prestamos = prestamos.stream()
                    .filter(p -> p.getUsuario().getId().equals(actualId))
                    .toList();
        }
        return prestamos.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<PrestamoResponseDTO> buscarPorUsuario(Long usuarioId) {
        Long objetivoId = usuarioActual.esSolicitante() ? usuarioActual.id() : usuarioId;
        return prestamoRepository.findByUsuarioId(objetivoId).stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<PrestamoResponseDTO> buscarVencidos() {
        List<Prestamo> vencidos = prestamoRepository.buscarVencidos(Instant.now());
        if (usuarioActual.esSolicitante()) {
            Long actualId = usuarioActual.id();
            vencidos = vencidos.stream()
                    .filter(p -> p.getUsuario().getId().equals(actualId))
                    .toList();
        }
        return vencidos.stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    @Transactional
    public PrestamoResponseDTO crear(PrestamoRequestDTO dto) {
        Recurso recurso = buscarRecurso(dto.recursoId());

        if (recurso.getEstadoOperativo() == EstadoOperativo.BLOQUEADO) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El recurso está BLOQUEADO y no puede ser prestado");
        }

        // RN-03: un recurso prestado no puede entregarse nuevamente hasta su devolución.
        if (recurso.getEstadoOperativo() == EstadoOperativo.PRESTADO) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "El recurso ya se encuentra PRESTADO; debe registrarse su devolución antes de entregarlo nuevamente");
        }

        if (recurso.getModalidadRecurso() != ModalidadRecurso.PRESTABLE && recurso.getModalidadRecurso() != ModalidadRecurso.AMBAS) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El recurso no permite la modalidad de préstamo");
        }

        Prestamo prestamo = new Prestamo();
        aplicarDatos(prestamo, dto);
        prestamo.setEstadoPrestamo(EstadoPrestamo.ACTIVO);
        prestamo.setDevolucionTardia(false);

        recurso.setEstadoOperativo(EstadoOperativo.PRESTADO);
        recursoRepository.save(recurso);

        return toResponse(prestamoRepository.save(prestamo));
    }

    @Override
    @Transactional
    public PrestamoResponseDTO registrarDevolucion(Long id, DevolucionRequestDTO dto) {
        Prestamo prestamo = buscarEntidad(id);

        if (prestamo.getEstadoPrestamo() != EstadoPrestamo.ACTIVO) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El préstamo ya ha sido devuelto anteriormente");
        }

        Instant ahora = Instant.now();
        prestamo.setFechaHoraDevolucion(ahora);
        prestamo.setEstadoFinal(dto.estadoFinal());
        if (dto.observaciones() != null && !dto.observaciones().isBlank()) {
            prestamo.setObservaciones(prestamo.getObservaciones() + " | Devolución: " + dto.observaciones());
        }
        prestamo.setEstadoPrestamo(EstadoPrestamo.DEVUELTO);

        boolean esTardia = ahora.isAfter(prestamo.getFechaHoraLimite());
        prestamo.setDevolucionTardia(esTardia);

        Recurso recurso = prestamo.getRecurso();
        recurso.setEstadoOperativo(EstadoOperativo.DISPONIBLE);
        recursoRepository.save(recurso);

        return toResponse(prestamoRepository.save(prestamo));
    }

    @Override
    @Transactional
    public PrestamoResponseDTO actualizar(Long id, PrestamoRequestDTO dto) {
        Prestamo prestamo = buscarEntidad(id);
        aplicarDatos(prestamo, dto);
        return toResponse(prestamoRepository.save(prestamo));
    }

    @Override
    public void eliminar(Long id) {
        if (!prestamoRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Prestamo no encontrado: " + id);
        }
        prestamoRepository.deleteById(id);
    }

    private void validarPropiedad(Prestamo prestamo) {
        if (usuarioActual.esSolicitante() && !prestamo.getUsuario().getId().equals(usuarioActual.id())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "No tiene permiso para acceder a este préstamo");
        }
    }

    private void aplicarDatos(Prestamo prestamo, PrestamoRequestDTO dto) {
        prestamo.setFechaHoraEntrega(dto.fechaHoraEntrega());
        prestamo.setFechaHoraLimite(dto.fechaHoraLimite());
        prestamo.setEstadoInicial(dto.estadoInicial());
        prestamo.setObservaciones(dto.observaciones());
        prestamo.setAccesorios(dto.accesorios());
        prestamo.setRecurso(buscarRecurso(dto.recursoId()));
        prestamo.setUsuario(buscarUsuario(dto.usuarioId()));
        prestamo.setReserva(buscarReserva(dto.reservaId()));
    }

    private Prestamo buscarEntidad(Long id) {
        return prestamoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Prestamo no encontrado: " + id));
    }

    private Recurso buscarRecurso(Long id) {
        return recursoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Recurso no encontrado: " + id));
    }

    private Usuario buscarUsuario(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado: " + id));
    }

    private Reserva buscarReserva(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Reserva no encontrada: " + id));
    }

    private PrestamoResponseDTO toResponse(Prestamo prestamo) {
        return new PrestamoResponseDTO(
                prestamo.getId(),
                prestamo.getFechaHoraEntrega(),
                prestamo.getFechaHoraLimite(),
                prestamo.getFechaHoraDevolucion(),
                prestamo.getEstadoInicial(),
                prestamo.getEstadoFinal(),
                prestamo.getObservaciones(),
                prestamo.getAccesorios(),
                prestamo.getEstadoPrestamo(),
                prestamo.getRecurso().getId(),
                prestamo.getRecurso().getNombre(),
                prestamo.getUsuario().getId(),
                prestamo.getUsuario().getNombre(),
                prestamo.getReserva().getId(),
                prestamo.getDevolucionTardia()
        );
    }
}