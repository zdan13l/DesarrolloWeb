package com.sistema.gestion.sistema_gestion_api.modules.mantenimiento.repository;

import com.sistema.gestion.sistema_gestion_api.modules.mantenimiento.model.EstadoMantenimiento;
import com.sistema.gestion.sistema_gestion_api.modules.mantenimiento.model.Mantenimiento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface MantenimientoRepository extends JpaRepository<Mantenimiento, Long> {

    List<Mantenimiento> findByRecursoId(Long recursoId);

    List<Mantenimiento> findByEstadoMantenimiento(EstadoMantenimiento estadoMantenimiento);

    boolean existsByRecursoIdAndEstadoMantenimientoIn(Long recursoId, Collection<EstadoMantenimiento> estados);
}
